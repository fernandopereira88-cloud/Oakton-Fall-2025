def Empty():
    pass