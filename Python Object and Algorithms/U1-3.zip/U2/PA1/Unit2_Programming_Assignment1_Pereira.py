        
'''
######################################################################################################################################
STUDENT: FERNANDO CHIAVERINI ALBANO PEREIRA
DATE: 11/21/2025
ASSIGNMENT: Unit 2 Programming Assignment 1 - Number of 1’s

ASSIGNMENT QUESTIONS
1) What is the runtime complexity of binaryNumOfOnesRec?
-- binaryNumOfOnesRec is Big-Theta(log(n)). 
-- Master Teorem approach: 
--- The recurrence equation for binaryNumOfOnesRec(n) is T(n) =  1 * T(n/2) + f(n), as the recursion is called only once (a = 1),
--- and the problem is space is reduced by half in each iteration (b = 2). The non-recurrence part of the algorithm is just constant statements,
--- so they should evaluate to O(1), so n^k*log^p(n) = 1 and k = 0 and p =0. Since Log(a= 1 base b=2) = 0 = k , it's case 2 of the teorem. 
--- Since p > -1, the complexity is Big-Theta(log(n)).
    

2) What is the runtime complexity of binaryNumOfOnesIter?
-- binaryNumOfOnesIter is also Big-Theta(log(n)).
-- Similar to binaryNumOfOnesRec, the problem space of binaryNumOfOnesIter also decreases by half in every iteration since n is updated
-- with the integer division of n by 2 in every iteration. Given that all other statements in the algorithm run in constant time,
-- binaryNumOfOnesIter is Big-Theta(log(n)).

######################################################################################################################################
'''

def adjustTo4k(binaryStr):
    '''
    Description: This function adjusts a binary number representation to have a multiple of 4 number of digits
    Input:  a binary representation of a natural number
    Output: a binary representation of a natural number that has a multiple of 4 number of digits with zeroes added to the left side when needed    
    '''    
    if binaryStr == "":
        binaryStr ="0"
    
    zeroesNeeded = (-len(binaryStr)) % 4
    
    return ("0"*zeroesNeeded) + binaryStr
        
    
def binaryNumOfOnesRec(x):
    '''
    Description: Recursive version of a function that takes a natural number, convert it to binary, and
                 outuputs the number of number ones present in the binary representation
    Input: N, an integer greater than or equal to 0.
    Output: a string representation of N in binary, and the number of 1’s in the binary representation of N.
            The string representation of N must be of size 4k, for k greater than or equal to 0.    
    '''    
    def recurrence(n):
        # Base case n = 0
        if n == 0:
            return ("",0)
        else:
            (binaryPrev,onesPrev) = recurrence(n//2)
            remainder = n % 2
            binary = binaryPrev + str(remainder)
            if remainder == 1: # if odd, remainder == 1, so increment ones
                ones = onesPrev +1
            else:
                ones = onesPrev
            return (binary,ones)
        
    binary, ones = recurrence(x)
    
    binary4k = adjustTo4k(binary)
    # binary4k = binary
    return binary4k, ones
    
def binaryNumOfOnesIter(n):
    '''
    Description: Iterative version of a function that takes a natural number, convert it to binary, and
                 outuputs the number of number ones present in the binary representation
    Input: N, an integer greater than or equal to 0.
    Output: a string representation of N in binary, and the number of 1’s in the binary representation of N.
            The string representation of N must be of size 4k, for k greater than or equal to 0.    
    '''
    binary = ""
    ones = 0    
    while n >0:
        remainder = n % 2
        ones += remainder
        n = n//2
        binary = str(remainder) + binary
        
    binary4k = adjustTo4k(binary)
        
    return binary4k,ones

def main():
    '''
    Main function to run and print results for numbers requested for assinment test driver 
    '''
    
    numbersList = [0,1,17,123,2048,2**31,2**31-1]
    
    print("\nRecursive")
    for item in numbersList:        
        resultRec = binaryNumOfOnesRec(item)
        print(f'Result: {item} is {resultRec[0]} in binary and has {resultRec[1]} number ones.')
                
    print("\nIter")        
    for item in numbersList:                            
        resultIter = binaryNumOfOnesIter(item)            
        print(f'Result: {item} is {resultIter[0]} in binary and has {resultIter[1]} number ones.')
                
if __name__ == "__main__":
    main()

