'''
ASSIGNMENT QUESTIONS:
1) How does the recursion terminate? [2 points]
Answer: the base case for the recursion happens when the input array of the majorityElementCandidate() has length less than 2. 
        In the base case, the array provided will either have the majority element candidate in it (length = 1), or the original array has no majority element candidates (lentgh = 0).
        
2) How is the case where N is odd handled? [2 points]
Answer: arrays with odd number of elements will have an element that has no other element for comparison according to the algorithm description. After trying some variations on how 
        to handle this last element (i.e.: comparing it with the first element of the array, ignoring it entirely, storing it in a oddTail vairable, etc.), the best strategy seems to be 
        to append the last element into array B after all comparisons have been performed. By doing so, the tail element helps preserve majority element candidates in the input array (arrayA)
        as candidates in the output array (arrayB), working almost as a tiebraker.
        
        Example: arrayA = [0,0,1,1,1] creates arrayB = [0,1,1] in first the recursion, and arrayB = [1] in the second recursion. If the tail element ([1]) were not appended at the end,
          the first recursion would mistakenly have created arrayB = [0,1], and return None as majority element candidates, so the "tiebreaker" is a must have element in the array, and in algorithm.
        
3) What is the runtime complexity of the algorithm in terms of Big-Oh? Solve a recurrence relation. [4 points]
Answer: O(n). Both the recursion in part one and the sequential search in part two have complexity runtime equal to O(n) each.
        While each recursive call has a problem that is half the size of the original problem scope, the algorithm requires a loop through the whole array before the recursion.
        
        Application of the master theorem to solve the recurrence relation:
        - Recurrence relation: T(n) = a * T(n/b) + f(n)
            - a = 1 as there is only one recursion function call per recursion
            - b = 2 as the problem is halved in each recursion (in the worst case - i.e.: [1,1,1,1,1,1])
            - f(n) is O(n) and Big-Theta(n) as the non-recursive portion of the algorithm requires a loop of size n before calling the recursion, meaning k = 1 and p = 0
            - Recurrance relation: T(n) = T(⌈n/2⌉) + Big-Theta(n)
            - Solving the recurrence with Master theorem: Case 3 as log(1 base 2) = 0 < k = 1. Since p = 0 and k =1, the recurrence is Big-Theta(n)


4) How can we avoid using an extra array, B? [2 points]
    -  Through research, I have found an algorithm with relative advantage to using array B: the Boyer–Moore Majority Vote. 
       This vote algorithm maintains a (candidate, count) while iterating through the array, assigning elements to a candidate variable whenever count==0, 
       incrementing count when the next item equals candidate, and decreasing count when the next item is not equal to the candidate. Once the iteration
       is completed, the algorithm performs a sequential search to verify whether the cnadidate is a majority.This vote algorithm also performs in O(n) time,
       but has O(1) space as it requires only one array and a couple of variable.
    
5) Write a program to compute the majority element and test it accordingly. [10 points]
    - See program below.
'''


                                                                                                        
def majorityElementCandidate(arrayA):
    '''
    Description:
        - A recursive algorithm to find the only possible majority element candidate in an array by comparing
          adjacent element pairs in the array, saving pairs with equal elements into a smaller array for recursion,
          and, appending the tail element whenever the array has an odd number of elements.
        - The base case is reached when the array has less than 2 elements in it, at which point either the remaining element
          or None is returned as the majority element candidate for the original array
    Inputs: 
        - An array with elements to be compared
        
    Outputs: 
        - A majority element candidate from the array or None in case there are no candidates in the array
    '''    
    arrayB = []
    n = len(arrayA)
    
    if n == 0 :
        return None
    elif n == 1:
        return arrayA[0]
                
    for index in range(0,n-1,2):                               
        if arrayA[index] == arrayA[index+1]:
            arrayB.append(arrayA[index]) 
    if len(arrayA) % 2 == 1:
        arrayB.append(arrayA[-1]) 
                            
    return majorityElementCandidate(arrayB)    

def majorityElementCandidateOneArray(arrayA):
    '''    
    '''
    
    candidate, counter = None, 0
    for x in arrayA:
        if counter == 0:
            candidate, count = x, 1
        elif x == candidate:
            count += 1
        else:
            count -= 1
            
    return candidate            
     
         
def majorityElement(aArray,oneArrayRecursion=0):
    '''
    '''    
    # First step: look for a majority element candidate in the array
    if oneArrayRecursion == 1:
        candidate = majorityElementCandidateOneArray(aArray)
    else:
        candidate = majorityElementCandidate(aArray)
    
    # Second step: determines whether the candidate is actually the majority element
    if candidate is None:
        return "There are no majority elements in the array provided."
    else:
        counter = 0
        for item in aArray:
            if candidate == item:
                counter +=1    
                
        if counter > len(aArray)//2:
            return f"{candidate} is a majority element in the array provided."
        else:
            return "There are no majority elements in the array provided."

testArrays =[
    [['None'],[1,2,3]],
    [['1'],[1,1,1,2,2]],
    [['1'],[1,1,2,2,1,1]],
    [['None'],[1,1,2,2,1,3]],
    [['1'],[1,1,1,2,2]],
    [['1'],[1,2,1,2,1]],
    [['1'],[2,1,1,2,1]],
    [['None'],[1,1,3,4,5]],
    [['1'],[2,1,1,2,1,2,1]],
    [['1'],[2,1,1,2,1,2,1]],
    [['1'],[0,0,1,1,1]]
    ]

print()    
print("==============================")    
print("Using TWO arrays for recursion")    
print("==============================")    
for item in testArrays:
    print(f"Expect {item[0]}\t {majorityElement(item[1],0)}")


print()
print("Using ONE array for recursion")    



# Algorithm carrying last element in odd size array into an oddTail variabl
# def majorityElementCandidateAlternative(arrayA,oddTail=None):
#     '''
#     Description:
#         - A recursive algorithm to find the only possible majority element candidate in an array by comparing
#           adjacent element pairs in the array, saving pairs with equalt elements into a smaller array for recursion,
#           and storing a tail element to handle odd sized arrays.
#         - The base case is reached when the array is reduced to zero elements, at which point oddTail returns either
#           the majority element candidate or None.
#     Inputs: 
#         - An array and an oddTail (defined as the last element of an array that has an odd number of elements). 
#         - oddTail is optional for the user and used by the algorithm 
#     Outputs: a majority element candidate from the array or None in case there are no candidates in the array
#     '''    
#     arrayB = []
#     n = len(arrayA)
    
#     if n == 0 :
#         return oddTail
    
#     if len(arrayA) % 2 == 1:
#         oddTail = arrayA[-1]
    
#     for index in range(0,n-1,2):                               
#         if arrayA[index] == arrayA[index+1]:
#             arrayB.append(arrayA[index]) 
# 
# def majority(data, tiebreaker =None): #// complete code, with testing, in majority.py
    '''Return the majority element of sequence data, OR
    tiebreaker - if exactly half of the elements in data are tiebreaker , OR
    None otherwise.
    '''
    n = len(data)
    if n == 0:
        return tiebreaker
    pairs = [] # empty list
    if n % 2 == 1:
        tiebreaker = data[-1] # last element in Python sequence
    for i in range(0, n-1, 2): # for(i = 0; i < n-1; i+=2)
        if data[i] == data[i+1]:
            pairs.append(data[i])
    major = majority(pairs, tiebreaker )
    
    if major is None:
        return None
    nMajor = data.count(major) # handy method does the obvious
    if 2*nMajor > n or (2*nMajor == n and major == tiebreaker ):
        return major
    return None # candidate did not pan out


print(majority(data=[1,1,2,2,1,1]))
print(majority(data=[1,2,1,2,1]))


# '''
# ASSIGNMENT QUESTIONS:
# 1) How does the recursion terminate? [2 points]
# Answer: the base case for the recursion happens when the input array of the majorityElementCandidate() has length equal to 0. 
#         In the base case, the algorithm will return the final value in oddTail as the majority element candidate for the array.
        
# 2) How is the case where N is odd handled? [2 points]
# Answer: arrays with odd number of elements will have an element that has no other element for comparison according to the algorithm description. After trying some variations on how 
#         to handle this last element (i.e.: comparing it with the first element of the array, ignoring it entirely, appending it to array B, etc.), the best strategy seems to be 
#         to carry the element into the next recursion by assigning it to the variable oddTail. By doing so, the tail element preserves any tiebreaks among majority element candidates in arrayA.
#         The examples below illustrate the importance of the last element in odd sized arrays and how simply appending it into arrayB does not guarantee correctness.
        
#         Examples: 
#         1) The last element in odd sized arrays is required to identify majority element candidates:
#             The arrayA = [0,0,1,1,1] creates arrayB = [0,1] and oddTail = 1 in first the first pass, and arrayB = [] and oddTail = 1 in the recursion, returning 1 as candidate.
#             If the tail element ([1]) were not carried, the algorithm would have mistakenly returned no candidates.
          
#         2) Appending the last element doesn't always work:
#             The arrayA = [1,1,1,2,2] creates arrayB = [1] and oddTail = 2 in the first pass, and arrayB = [] and oddTail = 1 in the recursion, returning 1 as candidate.
#             If the last element [2] were to simply be appended into arrayB, resulting in arrayB = [1,2] instead of being carried in oddTail, the recursion would mistakenly not have
#             found any majority element candidates.
        
# 3) What is the runtime complexity of the algorithm in terms of Big-Oh? Solve a recurrence relation. [4 points]
# Answer: O(n). Both the recursion in part one and the sequential search in part two have complexity runtime equal to O(n) each.
#         While each recursive call has a problem that is half the size of the original problem scope, the algorithm requires a loop through the whole array before the recursion.
        
#         Application of the master theorem to solve the recurrence relation:
#         - Recurrence relation: T(n) = a * T(n/b) + f(n)
#             - a = 1 as there is only one recursion function call per recursion
#             - b = 2 as the problem is halved in each recursion (in the worst case - i.e.: [1,1,1,1,1,1])
#             - f(n) is O(n) and Big-Theta(n) as the non-recursive portion of the algorithm requires a loop of size n before calling the recursion, meaning k = 1 and p = 0
#             - Recurrance relation: T(n) = T(⌈n/2⌉) + Big-Theta(n)
#             - Solving the recurrence with Master theorem: Case 3 as log(1 base 2) = 0 < k = 1. Since p = 0 and k =1, the recurrence is Big-Theta(n)


# 4) How can we avoid using an extra array, B? [2 points]
#     -  Through research, I have found an algorithm with relative advantage to using array B by using only the original array and a couple of control variables: the Boyer–Moore Majority Vote. 
#        This voting algorithm maintains a (candidate, count) while iterating through the array, assigning elements to a candidate variable whenever count reaches zero, 
#        incrementing count when the next item equals candidate, and decreasing count when the next item  in the array is not equal to the current candidate. Once the iteration
#        is completed, the algorithm performs a sequential search to verify whether the candidate is a majority.This vote algorithm also performs in O(n) time,
#        but has O(1) space as it requires only one array and a couple of variable.
       
#     -  Another approach that could avoid the extra array B is counting elements through nested loops and evaluating the majority element test for each element. 
#        However, that approach is O(n^2), so less time efficient.
    
# 5) Write a program to compute the majority element and test it accordingly. [10 points]
#     - See program below for the two array algorithm implementation.
# '''

# def majorityElementCandidate(arrayA,oddTail=None):
#     '''
#     Description:
#         - A recursive algorithm to find the only possible majority element candidate in an array by comparing
#           adjacent element pairs in the array, saving pairs with equalt elements into a smaller array for recursion,
#           and storing a tail element to handle odd sized arrays.
#         - The base case is reached when the array is reduced to zero elements, at which point oddTail returns either
#           the majority element candidate or None.
#     Inputs: 
#         - An array and an oddTail (defined as the last element of an array that has an odd number of elements). 
#         - oddTail is optional for the user and used by the algorithm 
#     Outputs: a majority element candidate from the array or None in case there are no candidates in the array
#     '''    
#     arrayB = []
#     n = len(arrayA)
    
#     if n == 0 :
#         return oddTail
    
#     if len(arrayA) % 2 == 1:
#         oddTail = arrayA[-1]
    
#     for index in range(0,n-1,2):                               
#         if arrayA[index] == arrayA[index+1]:
#             arrayB.append(arrayA[index])
            
#     return majorityElementCandidate(arrayB,oddTail)                                                                    
                       
# # Alternative version of majorityElementCandidate appending last element for odd-sized arrays. 
# # The algorithm doesn't always return candidates correctly (see answers for assignment questions), so it was commented.
# # def majorityElementCandidate(arrayA):
# #     '''
# #     Description:
# #         - A recursive algorithm to find the only possible majority element candidate in an array by comparing
# #           adjacent element pairs in the array, saving pairs with equal elements into a smaller array for recursion,
# #           and, appending the tail element whenever the array has an odd number of elements.
# #         - The base case is reached when the array has less than 2 elements in it, at which point either the remaining element
# #           or None is returned as the majority element candidate for the original array
# #     Inputs: 
# #         - An array with elements to be compared
        
# #     Outputs: 
# #         - A majority element candidate from the array or None in case there are no candidates in the array
# #     '''    
# #     arrayB = []
# #     n = len(arrayA)
    
# #     if n == 0 :
# #         return None
# #     elif n == 1:
# #         return arrayA[0]
                
# #     for index in range(0,n-1,2):                               
# #         if arrayA[index] == arrayA[index+1]:
# #             arrayB.append(arrayA[index]) 
# #     if len(arrayA) % 2 == 1:
# #         arrayB.append(arrayA[-1]) 
                            
# #     return majorityElementCandidate(arrayB)    

# def majorityElementCandidateOneArray(arrayA):
#     '''    
#     '''
    
#     candidate, counter = None, 0
#     for x in arrayA:
#         if counter == 0:
#             candidate, count = x, 1
#         elif x == candidate:
#             count += 1
#         else:
#             count -= 1
            
#     return candidate            
     
         
# def majorityElement(aArray,oneArrayRecursion=0):
#     '''
#     '''    
#     # First step: look for a majority element candidate in the array
#     if oneArrayRecursion == 1:
#         candidate = majorityElementCandidateOneArray(aArray)
#     else:
#         candidate = majorityElementCandidate(aArray)
    
#     # Second step: determines whether the candidate is actually the majority element
#     if candidate is None:
#         return "There are no majority elements in the array provided."
#     else:
#         counter = 0
#         for item in aArray:
#             if candidate == item:
#                 counter +=1    
                
#         if counter > len(aArray)//2:
#             return f"{candidate} is a majority element in the array provided."
#         else:
#             return "There are no majority elements in the array provided."
# def main():
#     '''
#     Description: 
#         - Main assignment function and driver. Defines a sample of lists of lists with [['Expected Result'],[array to be tested]] called testArrays and
#           calls the function to search for majority elements in the array.
#     '''
#     testArrays =[
#         [['None'],[1,2,3]],
#         [['1'],[1,1,1,2,2]],
#         [['1'],[1,1,2,2,1,1]],
#         [['None'],[1,1,2,2,1,3]],
#         [['1'],[1,1,1,2,2]],
#         [['1'],[1,2,1,2,1]],
#         [['1'],[2,1,1,2,1]],
#         [['None'],[1,1,3,4,5]],
#         [['1'],[2,1,1,2,1,2,1]],
#         [['1'],[2,1,1,2,1,2,1]],
#         [['1'],[0,0,1,1,1]]
#         ]    
#     print()    
#     print("==============================")    
#     print("Finding Majority Elements")    
#     print("==============================")    
#     for item in testArrays:
#         expectedResult = item[0]
#         result = majorityElement(item[1],0)
        
#         print(f"Expect {expectedResult}\t {result}")
    

# if __name__ == '__main__':
#     main()



