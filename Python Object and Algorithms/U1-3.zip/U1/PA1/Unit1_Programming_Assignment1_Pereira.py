'''
############################################################################################################################
STUDENT: FERNANDO CHIAVERINI ALBANO PEREIRA
DATE: 10/20/2025
############################################################################################################################
ASSIGNMENT: Binary Search Two-way Comparison
Implement the binary search algorithm so that only one (1) two-way comparison is performed in
each iteration of the while loop. The original algorithm has two (2) two-way comparisons in the while loop 
(the first: if, and the second: else if or elif). 

Make the necessary changes to the conditional statements so that there is only one two-way comparison. 
Essentially, think about removing the second two-way comparison altogether. 


QUESTIONS:
1) What is the count of comparisons of binary_search given an input array of size N for
the original version?

    ANSWER: 
    In the worst case, the original binary_search algorithm performs 2*floor(log(N))+2 comparisons because the searchable array size
    is reduced by 50% in each iteration (floor(log(N)) iterations), and both comparison statements are executed in each iteration, 
    including a final comparison at the end of the search. This scenario happens when the algorithm is requested to search for an item that is smaller
    than the smallest item on the array (out of bounds) as 'arr[mid]' will be higher than 'low' until the last search iteration,  
    and this condition will trigger both comparison statements.
    
    Asymptotically, the algorithm itself performs at Θ(log(N)), because, as mentioned,  the conditional statements reduce the searchable 
    part of the array by 50% in each iteration, and constants can be ignored. 
    
    Additional considerations on the 'elif' statement execution:
        The 'elif' statement only runs when 'high' needs to be adjusted or when the algorithm reaches the end of the search. 
        Therefore, 
            in the worst case, the 'elif' statement will execute the same number of times as the 'if' statements. 
            This scenario is O(2*log(n)) and happens when the target value is at the first index in the array or below it 
            (out of bounds).
            
            in the best case, the 'elif' statement will execute one time at the end of the search.
            This scenario is O(1) and happens either when the first item in the search is the target item, 
            or when the target item is the highest element in the array.
                                    
                 
2) What is the count of comparisons of binary_search given an input array of size N for
the updated and improved version?

    ANSWER: 
    Since the adjusted algorithm has only one control statement, it will only execute log(n)+1 comparisons in the worst case.
    Asymptotically, it also performs at Θ(log(N)).
    

############################################################################################################################
############################################################################################################################
'''

def original_binary_search(arr, x):
    '''
    Performs a binary search in an ordered array applying two two-way comparisons inside the while loop.
    Inputs:
        - arr: the array in which the search will be performed
        - x: the element to be searched
    Outputs:
        - If the item is found, the function returns the index of the item in the array and number of comparisons
        - If the item is not found, the function returns -1 and number of comparisons
    '''    
    low, high = 0, len(arr) - 1
    
    # the print below was used to understand the algorithm traversal and observe complexity
    # print('|  t  | low | high | mid | if    | elif    |')

    t= 0    
    while low <= high:
        mid = (low + high) // 2
        t += 1
        if arr[mid] < x:
            low = mid + 1
        elif arr[mid] > x:
            t += 1
            high = mid - 1
        else:        
            return f'Index = {mid} Comparisons = {t}'
        
        # the print below was used to understand the algorithm traversal and observe complexity
        # print('| ',t,' | ',low,' | ',high,'  | ',mid,' |', arr[mid] < x,' | ','-----' if arr[mid] < x else arr[mid] > x,' |')
                  
    return f'Index = {-1} Comparisons = {t}' # NOT_FOUND

def adjusted_binary_search(arr, x):
    '''
    Performs an adjusted binary search in an ordered array applying just one two-way comparison inside the while loop.
    Inputs:
        - arr: the array in which the search will be performed
        - x: the element to be searched
    Outputs:
        - If the item is found, the function returns the index of the item in the array and number of comparisons
        - If the item is not found, the function returns -1 and number of comparisons
    '''    
    low, high = 0, len(arr) - 1
    t=0
    while low <= high:
        mid = (low + high) // 2
        t += 1
        if arr[mid] < x:
            low = mid + 1
        else:
            high = mid - 1                 
        
            
    if low < len(arr) and arr[low] == x:
        return  f'Index = {low} Comparisons = {t}'
    
    return  f'Index = {-1} Comparisons = {t}' # NOT_FOUND

def driver(alist):
    '''
    Description: 
    - Driver program for binary tree search. Searches an array using original and adjusted binary tree algorithms
    
    Inputs: - an ordered array (list).
    Outputs: - a print with the binary tree search results for all items in the arrays, including out of bounds.
    
    '''
    print()
    print('==============')
    print("DRIVER RESULTS")
    print('==============')
    for i in range(0,len(alist)+2):

        print("\nLooking for:",i,"List:",alist,"\nOriginal:",original_binary_search(alist,i),"\nAdjusted:",adjusted_binary_search(alist,i))        
        
driver(alist = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20])