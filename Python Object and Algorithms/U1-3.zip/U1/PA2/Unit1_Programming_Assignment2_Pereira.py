'''
############################################################################################################################
STUDENT: FERNANDO CHIAVERINI ALBANO PEREIRA
DATE: 11/19/2025
############################################################################################################################
ASSIGNMENT: Searching Methods over Various Data Structures: Heaps, Hash Tables, and Trees

RUNTIME ANALYSIS FOR PART B2 and B3:
 - The first disclaimer to mention in this analysis is that runtimes could be impacted by competing processing activities being performed by the CPU during execution of the script. 
   With that said, see below for run time analysis.
   
    - Most frequent word: 
        - When looking for the top word in PatriotAct.txt, the Binary Heap had the shortest time as expected, since the top word can be accessed by looking at the top of the heap (it's just one task,so performs at O(1)).
        - The second fastest data structure was the Hash Table, followed by the BST. 
            - Both need to loop through all words to check first what is the highest word count in the content as the word count is a value, and not a key. 
                - This loop requires getting word counts for the words up to two times, first to test whether the current word in the loop word count is higher than the current maximum word count found in the loop, 
                  and second to assign the word count to the max word count variable. For the Hash Table, this task of getting word count is expected to run at O(1), but could be up to O(n) in the worst case, considering hash table collisions.
                  For the BST, this getting word is expected to run at O(h) in which h is the height of the BST. 
                - Taking the loop and the complexity of getting items for each structure, one would expect the Hash Table to perform faster than the BST as observed in the report.            
                    
    - Specific word look up:
        - Overall analysis:
            - Generally speaking, 
                - The Hash table should be the fastest at looking up items since it can use the hash function to calculate indexes and reach them on the hash table (expected O(1)). 
                    - However, look ups can be longer if there are collisions (up to O(n))
                - The BST won't be as fast as the Hash Table for the most common words in the content as those will be at the top of the heap and can bre retrieved with shorter searches. 
                    - However, the BST search should catch up quickly in speed as its runtime is a function of the BST's height (O(n), while looking items up on the heap requires surveying all items (runtime grows towards O(n))
                
        - 'terrorists': 
            - As expected from the general case, the Hash Table was the fastest to find this word. 
            - The BST was the second fastest, and the Heap was the slowest. This is reasonable because 'terorrists' is not at the top of the heap, so the BST reaches faster as it performs at O(h) vs O(n) for the heap.
            
        - 'the' (most common word):
            - This is the most frequent word, so the heap data structure should find it at the beginning of the search. As expected the heap had the smallest runtime, since this is the best look up case and finds this specific word at O(1).
            - The hash table is expected to perform at O(1) to get items too, but could have a slower runtime caused by collisions in the hash table.
            - The BST took the longest in this search because it is expected to search at O(h), which is more complex than the other two data structures.
    
        - 'freedom' (word not present in content):
            - The heap had the worst performance because it has to go through all items in the heap when the word is not part of the heap, performing at O(n)
            - The hash table had the best runtime performance as it uses the hash function and probing to look up the word (O(1) to find the initial position on the hash table, then up to O(n) if there are collisions)
            - The BST had the second best runtime performance when looking for a word that is not in the content. This performance also makes sense because the BST problem scope is reduced each step of the search given the ordering of BSTs 
              (smaller items to the left branch and higher items to the right branch). The search performs at O(h) in which h is the height of the BST. This is not as fast as the hash table (O(1)), but it is likely to be faster than the heap (O(n)).
            
        
main() OUTPUT LOG with runtime reports:

******************************************************************************
******************************************************************************
********************* PART A *************************************************
******************************************************************************
******************************************************************************

==============================
=== HEAP SEARCH ==============
==============================
Rank 5: pink
Rank 2: brown
Rank 11: Item not found

====================================
=== HASH TABLE SEARCH ==============
====================================
Pink Rank:       5
Green Rank:      8
Grey Rank:       -1

============================================
=== BINARY SEARCH TREE SEARCH ==============
============================================
White Rank:      9
Black Rank:      6
Violet Rank:     -1

******************************************************************************
******************************************************************************
********************* PART B *************************************************
******************************************************************************
******************************************************************************

==================================
=== TOP WORD SEARCH ==============
==================================
HEAP: The top word count is 'the', and it has been counted 111 times.           Runtime: 0.0000479221
HASH TABLE: The top word count is 'the', and it has been counted 111 times.     Runtime: 0.0003619194
BST: The top word count is 'the', and it has been counted 111 times.            Runtime: 0.0047450066

======================================================
=== SEARCHING FOR THE WORD 'terrorists' ==============
======================================================
HEAP - Word count for the word 'terrorists':       13           Runtime: 0.0000231266
HASH TABLE - Word count for the word 'terrorists': 13           Runtime: 0.0000030994
BST - Word count for the word 'terrorists':        13           Runtime: 0.0000081062

======================================================
=== SEARCHING FOR THE WORD 'the' =====================
======================================================
HEAP - Word count for the word 'the':            111            Runtime: 0.0000000000
HASH TABLE - Word count for the word 'the':      111            Runtime: 0.0000007153
BST - Word count for the word 'the':             111            Runtime: 0.0000090599

======================================================
=== SEARCHING FOR THE WORD 'freedom' =================
======================================================
HEAP - Word count for the word 'freedom':        Item not found Runtime: 0.0000178814
HASH TABLE - Word count for the word 'freedom':  -1             Runtime: 0.0000021458
BST - Word count for the word 'freedom':         -1             Runtime: 0.0000131130

############################################################################################################################
############################################################################################################################
'''

from goodrich.ch11.binary_search_tree import TreeMap
from goodrich.ch10.probe_hash_map import ProbeHashMap
from goodrich.ch10.quadratic_probe_hash_map_pereira import QuadraticProbeHashMap
from goodrich.ch09.max_heap_priority_queue_pereira import MaxHeapPriorityQueue
import time
from pathlib import Path

def partA():
    '''
    This function executes the items requested in part A:
    - Creates and insert requested pairs into binary max heap, has table size 11, and Binary Search Tree.
    - For each data structure perform requested searches and report it back.
    '''
    
    stringPairsSet = {("orange", 4), ("blue", 7), ("pink", 5), ("black", 6), ("green", 8),("yellow", 1), ("brown", 2), ("red", 3), ("purple", 10), ("white", 9) }    
    
    # Part A - Instantiate and Search
    # Instantiating objects    
    stringPairsHeap = MaxHeapPriorityQueue()  # HEAP
    stringPairsHashTable = ProbeHashMap(cap=11) #HashMapBase\ProbeHashMap
    stringPairsBST = TreeMap() # Binary Search Tree
    
    # Adding set pair items to objects
    for item in stringPairsSet:        
        #Insert values into heap
        stringPairsHeap.add(key=item[1],value=item[0])
        # Insert values into Hash Table size 11
        stringPairsHashTable[item[0]] = item[1] # Is it size 11?
        # Insert values into Binary Search Tree
        stringPairsBST[item[0]] = item[1] 
        
    # Displaying Data object items
    # print()
    # print("MAX BINARY HEAP:",(stringPairsHeap._data)) 
    # print()    
    # print("HASH TABLE:")
    # for key,value in stringPairsHashTable.items():        
    #     print(" - Key:",key,"\tValue:",value)
        
    # HEAP
    print()    
    print("==============================")
    print("=== HEAP SEARCH ==============")
    print("==============================")
    for i in (5,2,11):
        searchResult = stringPairsHeap.search_key(key=i)
        print(f"Rank {i}: {searchResult}")    
    
    
    # HASH TABLE 
    #       - Search for “pink”, and return the associated rank
    #       - Search for “green”, and return the associated rank
    #       - Search for “grey”, and return -1 for item not found    
    print()
    print("====================================")
    print("=== HASH TABLE SEARCH ==============")
    print("====================================")    
    print("Pink Rank:\t",stringPairsHashTable['pink'])
    print("Green Rank:\t",stringPairsHashTable['green'])
    print("Grey Rank:\t",stringPairsHashTable['grey'])

    
    # 2.0) BINARY SEARCH TREE
    print()
    print("============================================")
    print("=== BINARY SEARCH TREE SEARCH ==============")
    print("============================================")    
    print("White Rank:\t",stringPairsBST['white'])
    print("Black Rank:\t",stringPairsBST['black'])
    print("Violet Rank:\t",stringPairsBST['violet'])    
    print()
        
def partB():
    '''
    This function executes the items requested in part B:
    - Reads the content in PatriotAct.txt, and store the content in three different data structures: heap, hash table, and Binary Search Tree
    - The hash table uses quadratic probing and has size 1723
    - An analysis of runtime is performed to dins the most common word, and the words "terrorists", "the, and "freedom" for each strutcure
    '''    
    
    # 1 - READ FILE
    script_dir = Path(__file__).resolve().parent
    file_path = script_dir / "PatriotAct.txt"
    with open(file_path,'r',encoding='cp1252') as file:    
        
        content = file\
                    .read()\
                    .replace('"','')\
                    .replace('(','')\
                    .replace(')','')\
                    .replace(':','')\
                    .replace(',','')\
                    .replace('.','') 
            # removing unwanted characters
    contentLowerCase = content.lower()    
    
    # 1.1 - CREATE WORD SET
    patriotSet = set(contentLowerCase.split())
    
    # 2 - CREATE PAIRS (word, count)
    patriotWordCountSet = set()
    for wordSet in patriotSet:
        wordCount=0
        for wordContent in contentLowerCase.split():
            if wordSet == wordContent:
                wordCount += 1
        patriotWordCountSet.add(tuple((wordSet,wordCount)))
            
       
    # Instantiating objects    
    patriotWordCountHeap = MaxHeapPriorityQueue()  # HEAP
    patriotWordCountHashTable = QuadraticProbeHashMap(cap=1723) #HashMapBase\ProbeHashMap
    patriotWordCountBST = TreeMap() # Binary Search Tree
    
    for item in patriotWordCountSet:        
        #Insert values into heap
        patriotWordCountHeap.add(key=item[1],value=item[0])
        # Insert values into Hash Table size 11
        patriotWordCountHashTable[item[0]] = item[1] 
        # Insert values into Binary Search Tree
        patriotWordCountBST[item[0]] = item[1] 

    
    print()    
    print("==================================")
    print("=== TOP WORD SEARCH ==============")
    print("==================================")
    # Heap
    startTime = time.time()
    topWord = patriotWordCountHeap.max()
    endTime = time.time()
    runtime = endTime - startTime    
    print(f"HEAP: The top word count is '{topWord[1]}', and it has been counted {topWord[0]} times. \t\tRuntime: {runtime:.10f}")

    # Hash Table
    maxCountHashTable = 0
    startTime = time.time()    
    for item in patriotWordCountHashTable:
        if patriotWordCountHashTable[item] > maxCountHashTable:
            maxCountHashTable = patriotWordCountHashTable[item]
            maxWordHashTable = item
    endTime = time.time()
    runtime = endTime - startTime    
    print(f"HASH TABLE: The top word count is '{maxWordHashTable}', and it has been counted {maxCountHashTable} times. \tRuntime: {runtime:.10f}")

    # BST
    maxCountBST = 0
    startTime = time.time()
    for item in patriotWordCountBST:
        if patriotWordCountBST[item] > maxCountBST:
            maxCountBST = patriotWordCountBST[item]
            maxWordBST = item            
    endTime = time.time()
    runtime = endTime - startTime    
    print(f"BST: The top word count is '{maxWordBST}', and it has been counted {maxCountBST} times. \t\tRuntime: {runtime:.10f}")
            
    print()
    print("======================================================")
    print("=== SEARCHING FOR THE WORD 'terrorists' ==============")
    print("======================================================")
    word = 'terrorists'
    
    startTime = time.time()
    wordCount = patriotWordCountHeap.search_value(value=word)
    endTime = time.time()
    runtime = endTime - startTime
    print(f"HEAP - Word count for the word '{word}':\t   {wordCount}\t\tRuntime: {runtime:.10f}")    
    
    startTime = time.time()
    wordCount = patriotWordCountHashTable[word]
    endTime = time.time()
    runtime = endTime - startTime    
    print(f"HASH TABLE - Word count for the word '{word}': {wordCount}\t\tRuntime: {runtime:.10f}")
    
    startTime = time.time()
    wordCount = patriotWordCountBST[word]
    endTime = time.time()
    runtime = endTime - startTime 
    print(f"BST - Word count for the word '{word}':\t   {wordCount}\t\tRuntime: {runtime:.10f}")

    print()
    print("======================================================")
    print("=== SEARCHING FOR THE WORD 'the' =====================")
    print("======================================================")
    word = 'the'
    
    startTime = time.time()
    wordCount = patriotWordCountHeap.search_value(value=word)
    endTime = time.time()
    runtime = endTime - startTime
    print(f"HEAP - Word count for the word '{word}':\t\t {wordCount}\t\tRuntime: {runtime:.10f}")    
    
    startTime = time.time()
    wordCount = patriotWordCountHashTable[word]
    endTime = time.time()
    runtime = endTime - startTime    
    print(f"HASH TABLE - Word count for the word '{word}':\t {wordCount}\t\tRuntime: {runtime:.10f}")
    
    startTime = time.time()
    wordCount = patriotWordCountBST[word]
    endTime = time.time()
    runtime = endTime - startTime 
    print(f"BST - Word count for the word '{word}':\t\t {wordCount}\t\tRuntime: {runtime:.10f}")    

    print()
    print("======================================================")
    print("=== SEARCHING FOR THE WORD 'freedom' =================")
    print("======================================================")
    word = 'freedom'
    
    startTime = time.time()
    wordCount = patriotWordCountHeap.search_value(value=word)
    endTime = time.time()
    runtime = endTime - startTime
    print(f"HEAP - Word count for the word '{word}':\t {wordCount} Runtime: {runtime:.10f}")    
    
    startTime = time.time()
    wordCount = patriotWordCountHashTable[word]
    endTime = time.time()
    runtime = endTime - startTime    
    print(f"HASH TABLE - Word count for the word '{word}':  {wordCount}\t\tRuntime: {runtime:.10f}")
    
    startTime = time.time()
    wordCount = patriotWordCountBST[word]
    endTime = time.time()
    runtime = endTime - startTime 
    print(f"BST - Word count for the word '{word}':\t {wordCount}\t\tRuntime: {runtime:.10f}")   
    print()    
    
        
def main():
    '''
    This function runs the funcitons that answer Part A and Part B of the assignment requests 
    '''
    # Part A - Instantiate and Search using Heap, Hash Tables, and Binary Search Trees
    print('******************************************************************************')
    print('******************************************************************************')
    print('********************* PART A *************************************************')
    print('******************************************************************************')
    print('******************************************************************************')    
    partA()
    
    print('******************************************************************************')
    print('******************************************************************************')
    print('********************* PART B *************************************************')
    print('******************************************************************************')
    print('******************************************************************************')
    partB()
    
if __name__ == "__main__":
    main()