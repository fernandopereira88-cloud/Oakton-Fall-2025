'''
Created on Feb 28, 2024

@author: Ivan Temesvari
'''
class Empty(Exception):
    """Exception raised for Empty container."""
    def __init__(self, message):
        self.message = message
        
    def __str__(self):
        return repr(self.message)