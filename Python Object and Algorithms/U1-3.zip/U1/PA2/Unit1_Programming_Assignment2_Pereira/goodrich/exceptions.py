

class Empty(Exception):
    pass