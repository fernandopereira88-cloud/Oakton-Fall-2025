

def Empty():
    pass