'''
############################################################################################################################
STUDENT: FERNANDO CHIAVERINI ALBANO PEREIRA
DATE: 11/19/2025
############################################################################################################################
ASSIGNMENT: Searching Methods over Various Data Structures: Heaps, Hash Tables, and Trees

RUNTIME ANALYSIS FOR PART B2 and B3:
 - The first disclaimer to mention in this analysis is that runtimes could be impacted by competing processing activities being performed by the CPU during execution of the script. 
   With that said, see below for run time analysis.
   
    - Most frequent word: 
        - When looking for the top word in PatriotAct.txt, the Binary Heap had the shortest time as expected, since the top word can be accessed by looking at the top of the heap (it's a O(1) task).
        - The second fastest data structure was the Hash Table
        - The slowest data structure was the BST
        
    - Specific word look up:
        - Overall analysis:
            - Generally speaking, 
                - The Hash table should be the fastest at looking up items since it can use the hash function to calculate indexes and reach them on the hash table (expected O(1)). 
                    - However, look ups can be longer if there are collisions (up to O(n))
                - The BST won't be as fast as the Hash Table for the most common words in the content as those will be at the top of the heap and can bre retrieved with shorter searches. 
                    - However, the BST search should catch up quickly in speed as its runtime is a function of the BST's height (O(n), while looking items up on the heap requires surveying all items (runtime grows towards O(n))
                
        - 'Terrorist': 
            - As expected from the general case, the Hash Table was the fastest to find this word. 
            - The BST was the second fastest, and the Heap was the slowest. This is expected because 'terorrist' is not at the top of the heap, so the BST reaches faster as it performs at O(h) vs O(n) for the heap.
            
        - 'the' (most common word):
            - This is the most frequent word, so the heap data structure should find it at the beginning of the search. As expected the heap had the smallest runtime, since this is the best look up case and finds this specific word at O(1).
            - The hash table is expected to perform at O(1) to get items, however it performed slower than the Heap in this look up probably. The difference is likely explained by collisions in the hash table.
            - The BST took the longest here because this word is probably at the bottom of the tree (it could potentially be a leaf).
    
        - 'freedom' (word not present in content):
            - The heap had the worst performance because it has to go through all items in the heap when the word is not part of the heap, performing at O(n)
            - The hash table had the best runtime performance as it uses the hash function and probing to look up the word (O(1) to find the initial position on the hash table, then up to O(n) if there are collisions)
            - The BST had the second best runtime performance when looking for a word that is not in the content. This performance also makes sense because the BST problem scope is reduced each step of the search given the ordering of BSTs 
              (smaller items to the left branch and higher items to the right branch). The search performs at O(h) in which h is the height of the BST. This is not as fast as the hash table (O(1)), but it is likely to be faster than the heap (O(n)).
            
        
main() OUTPUT LOG with runtime reports:

******************************************************************************
******************************************************************************
********************* PART A *************************************************
******************************************************************************
******************************************************************************

MAX BINARY HEAP: [(10,purple), (9,white), (7,blue), (5,pink), (8,green), (3,red), (6,black), (2,brown), (4,orange), (1,yellow)]

HASH TABLE:
 - Key: brown   Value: 2
 - Key: pink    Value: 5
 - Key: white   Value: 9
 - Key: purple  Value: 10
 - Key: red     Value: 3
 - Key: yellow  Value: 1
 - Key: green   Value: 8
 - Key: black   Value: 6
 - Key: blue    Value: 7
 - Key: orange  Value: 4

==============================
=== HEAP SEARCH ==============
==============================
Rank 5: {'pink'}
Rank 2: {'brown'}
Rank 11: {-1}

====================================
=== HASH TABLE SEARCH ==============
====================================
Pink Rank:       5
Green Rank:      8
Grey Rank:       -1

============================================
=== BINARY SEARCH TREE SEARCH ==============
============================================
White Rank:      9
Black Rank:      6
Violet Rank:     -1

******************************************************************************
******************************************************************************
********************* PART B *************************************************
******************************************************************************
******************************************************************************

==================================
=== TOP WORD SEARCH ==============
==================================
HEAP: The top word count is 'the', and it has been counted 111 times.           Runtime: 0.0000419617
HASH TABLE: The top word count is 'the', and it has been counted 111 times.     Runtime: 0.0008072853
BST: The top word count is 'the', and it has been counted 111 times.            Runtime: 0.0087399483

======================================================
=== SEARCHING FOR THE WORD 'terrorists' ==============
======================================================
HEAP - Word count for the word 'terrorists':       13           Runtime: 0.0000271797
HASH TABLE - Word count for the word 'terrorists': 13           Runtime: 0.0000028610
BST - Word count for the word 'terrorists':        13           Runtime: 0.0000092983

======================================================
=== SEARCHING FOR THE WORD 'the' =====================
======================================================
HEAP - Word count for the word 'the':            111            Runtime: 0.0000009537
HASH TABLE - Word count for the word 'the':      111            Runtime: 0.0000021458
BST - Word count for the word 'the':             111            Runtime: 0.0000088215

======================================================
=== SEARCHING FOR THE WORD 'freedom' =================
======================================================
HEAP - Word count for the word 'freedom':        -1             Runtime: 0.0000162125
HASH TABLE - Word count for the word 'freedom':  -1             Runtime: 0.0000009537
BST - Word count for the word 'freedom':         -1             Runtime: 0.0000081062
############################################################################################################################
############################################################################################################################
'''

from goodrich.ch11.binary_search_tree import TreeMap
from goodrich.ch10.probe_hash_map import ProbeHashMap
from goodrich.ch10.quadratic_probe_hash_map_pereira import QuadraticProbeHashMap
from goodrich.ch09.max_heap_priority_queue_pereira import MaxHeapPriorityQueue
import time
 
        
def partB():
    '''
    This function executes the items requested in part B:
    - Reads the content in PatriotAct.txt, and store the content in three different data structures: heap, hash table, and Binary Search Tree
    - The hash table uses quadratic probing and has size 1723
    - An analysis of runtime is performed to dins the most common word, and the words "terrorist", "the, and "freedom" for each strutcure
    '''    
    
    # 1 - READ FILE
    with open("PatriotAct.txt",'r',encoding='cp1252') as file:
        
        content = file\
                    .read()\
                    .replace('"','')\
                    .replace('(','')\
                    .replace(')','')\
                    .replace(':','')\
                    .replace(',','')\
                    .replace('.','') 
            # removing unwanted characters
    contentLowerCase = content.lower()    
    
    # 1.1 - CREATE WORD SET
    patriotSet = set(contentLowerCase.split())
    
    # 2 - CREATE PAIRS (word, count)
    patriotWordCountSet = set()
    for wordSet in patriotSet:
        wordCount=0
        for wordContent in contentLowerCase.split():
            if wordSet == wordContent:
                wordCount += 1
        patriotWordCountSet.add(tuple((wordSet,wordCount)))
            
       
    # Instantiating objects    
    patriotWordCountHeap = MaxHeapPriorityQueue()  # HEAP
    patriotWordCountHashTable = QuadraticProbeHashMap(cap=1723) #HashMapBase\ProbeHashMap
    patriotWordCountBST = TreeMap() # Binary Search Tree
    
    for item in patriotWordCountSet:        
        #Insert values into heap
        patriotWordCountHeap.add(key=item[1],value=item[0])
        # Insert values into Hash Table size 11
        patriotWordCountHashTable[item[0]] = item[1] 
        # Insert values into Binary Search Tree
        patriotWordCountBST[item[0]] = item[1] 

    
    print()    
    # print("==================================")
    # print("=== TOP WORD SEARCH ==============")
    # print("==================================")


    startTime = time.time()
    maxCountBST = 0
    startTime = time.time()
    for item in patriotWordCountBST:
        if patriotWordCountBST[item] > maxCountBST:
            maxCountBST = patriotWordCountBST[item]
            maxWordBST = item            
    endTime = time.time()
    runtime = endTime - startTime    
    print(f"BST: The top word count is '{maxWordBST}', and it has been counted {maxCountBST} times. \t\tRuntime: {runtime:.10f}")       
    
            
    # print()
    # print("======================================================")
    # print("=== SEARCHING FOR THE WORD 'terrorists' ==============")
    # print("======================================================")
    # word = 'terrorists'
    
    # startTime = time.time()
    # wordCount = patriotWordCountHeap.search_value(value=word)
    # endTime = time.time()
    # runtime = endTime - startTime
    # print(f"HEAP - Word count for the word '{word}':\t   {wordCount}\t\tRuntime: {runtime:.10f}")    
    
    # startTime = time.time()
    # wordCount = patriotWordCountHashTable[word]
    # endTime = time.time()
    # runtime = endTime - startTime    
    # print(f"HASH TABLE - Word count for the word '{word}': {wordCount}\t\tRuntime: {runtime:.10f}")
    
    # startTime = time.time()
    # wordCount = patriotWordCountBST[word]
    # endTime = time.time()
    # runtime = endTime - startTime 
    # print(f"BST - Word count for the word '{word}':\t   {wordCount}\t\tRuntime: {runtime:.10f}")

    # print()
    # print("======================================================")
    # print("=== SEARCHING FOR THE WORD 'the' =====================")
    # print("======================================================")
    # word = 'the'
    
    # startTime = time.time()
    # wordCount = patriotWordCountHeap.search_value(value=word)
    # endTime = time.time()
    # runtime = endTime - startTime
    # print(f"HEAP - Word count for the word '{word}':\t\t {wordCount}\t\tRuntime: {runtime:.10f}")    
    
    # startTime = time.time()
    # wordCount = patriotWordCountHashTable[word]
    # endTime = time.time()
    # runtime = endTime - startTime    
    # print(f"HASH TABLE - Word count for the word '{word}':\t {wordCount}\t\tRuntime: {runtime:.10f}")
    
    # startTime = time.time()
    # wordCount = patriotWordCountBST[word]
    # endTime = time.time()
    # runtime = endTime - startTime 
    # print(f"BST - Word count for the word '{word}':\t\t {wordCount}\t\tRuntime: {runtime:.10f}")    

    # print()
    # print("======================================================")
    # print("=== SEARCHING FOR THE WORD 'freedom' =================")
    # print("======================================================")
    # word = 'freedom'
    
    # startTime = time.time()
    # wordCount = patriotWordCountHeap.search_value(value=word)
    # endTime = time.time()
    # runtime = endTime - startTime
    # print(f"HEAP - Word count for the word '{word}':\t {wordCount}\t\tRuntime: {runtime:.10f}")    
    
    # startTime = time.time()
    # wordCount = patriotWordCountHashTable[word]
    # endTime = time.time()
    # runtime = endTime - startTime    
    # print(f"HASH TABLE - Word count for the word '{word}':  {wordCount}\t\tRuntime: {runtime:.10f}")
    
    # startTime = time.time()
    # wordCount = patriotWordCountBST[word]
    # endTime = time.time()
    # runtime = endTime - startTime 
    # print(f"BST - Word count for the word '{word}':\t {wordCount}\t\tRuntime: {runtime:.10f}")   
    print()    
    
        
def main():

    
    print('******************************************************************************')
    print('******************************************************************************')
    print('********************* PART B *************************************************')
    print('******************************************************************************')
    print('******************************************************************************')
    partB()
    
if __name__ == "__main__":
    main()