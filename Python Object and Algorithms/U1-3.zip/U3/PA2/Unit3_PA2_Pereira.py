'''
############################################################################################################################
STUDENT: FERNANDO CHIAVERINI ALBANO PEREIRA
DATE: 11/23/2025
############################################################################################################################
ASSIGNMENT: Sorting Comparisons 

Compare the following sorting algorithms: 
    - Heap sort
    - Insertion sort
    - Merge sort
    - Quick sort

ASSIGNMENT QUESTIONS:

Write a 200-word summary of your findings. In the summary, identify the best performing sorting algorithm 
and provide computational and analytical reasoning for why it performed better than the others. [25 points]

Answer:
The fastest algorithm was Quick sort and the slowest was Insertion Sort. 
While Quick sort is O(n^2) in the worst case, it can be O(n*logn) when L and G supporting lists are balanced.
In theory, Merge and Heap sorts are O(n*logn). Despite stronger theoretical complexity, Heap sort could have performed slower than Merge and Quick because of Python internal dynamic array adjustments. 
In addition, the Quick sort may have performed faster because it adopts in-place algorithm design, which may allow for faster data access compared to other algorithms.
The slow Insertion Sort performance was expected as the algorithm requires finding the smallest element to be pulled from the priority queue, making it O(n^2) in the worst case and O(n) in the best case.

size = 5,000
================
 RUNTIME REPORT
================
   Heap Sort  Insertion Sort  Merge Sort  Quick Sort
0   0.025908        1.780818    0.009540    0.005283
1   0.026976        1.768701    0.008768    0.004843
2   0.025055        1.754879    0.008790    0.004919
3   0.024929        1.772639    0.008754    0.004887
4   0.025608        1.787024    0.009169    0.004811

       Heap Sort  Insertion Sort  Merge Sort  Quick Sort
count   5.000000        5.000000    5.000000    5.000000
mean    0.025695        1.772812    0.009004    0.004949
std     0.000820        0.012294    0.000346    0.000192
min     0.024929        1.754879    0.008754    0.004811
25%     0.025055        1.768701    0.008768    0.004843
50%     0.025608        1.772639    0.008790    0.004887
75%     0.025908        1.780818    0.009169    0.004919
max     0.026976        1.787024    0.009540    0.005283


############################################################################################################################
############################################################################################################################
'''
from goodrich.ch09.heap_priority_queue import HeapPriorityQueue as minhpq
from goodrich.ch09.sorted_priority_queue import SortedPriorityQueue as spq
from goodrich.ch12.merge_array import merge_sort as ms
from goodrich.ch12.quick_inplace import inplace_quick_sort as iqs

import time
import random
import copy
import pandas as pd

def runHeapSort(heapSortList):
    '''
    Description: Performs the heap sort algorithm
    Inputs: a list with integer key and any type value pair tuples
    Outpus: modifies the input list to be sorted ascending
    '''
    heapData = minhpq()
    heapSize = len(heapSortList)
    for index in range(heapSize):
        key,value = heapSortList.pop()
        heapData.add(key,value)
        
    for index in range(len(heapData)):
        key,value = heapData.remove_min()
        heapSortList.append((key,value))
      
    # Support for printing  
    # for index in range(heapSize):
        # print(heapSortList[index][0],end=" ")       

def runInsertionSort(insertionSortList):
    '''
    Description: Performs the insertion sort algorithm
    Inputs: a list with integer key and any type value pair tuples
    Outpus: modifies the input list to be sorted ascending
    '''
    sortedPriorityQueue = spq()
    for index in range(len(insertionSortList)):
        key,value = insertionSortList.pop()
        sortedPriorityQueue.add(key,value)
        
    for index in range(len(sortedPriorityQueue)):
        key,value= sortedPriorityQueue.remove_min()
        insertionSortList.append((key,value))    

    # Support for printing
    # for index in range(len(insertionSortList)):
        # print(insertionSortList[index][0],end=" ")    
        
def runMergeSort(mergeSortList):
    '''
    Description: Performs the merge sort algorithm
    Inputs: a list with integer key and any type value pair tuples
    Outpus: modifies the input list to be sorted ascending
    '''

    ms(mergeSortList)
    # Support for printing
    # for index in range(len(mergeSortList)):        
        # print(mergeSortList[index][0],end=" ")

def runQuickSort(quickSortList):
    '''
    Description: Performs the quick sort algorithm
    Inputs: a list with integer key and any type value pair tuples
    Outpus: modifies the input list to be sorted ascending    
    '''
    size = len(quickSortList) 
    iqs(quickSortList,a=0,b=size-1)
    # Support for printing
    # for index in range(len(quickSortList)):        
        # print(quickSortList[index][0],end=" ")  
                    
def runSortingAlgorithms(data,n=5000):
    '''
    Description:
        - Call each of the sorting algorithms being analyzed to be executed for a list size n with integers randomly sorted. 
          A list with tuple key-value pairs is created to serve as input fo each algorithm
    Inputs:
        - A data list with integers as keys to be used by sorting algorithms, and n (the size of the list). The default value for size (n) is 5,000.
    Outputs:
        - Besides performing the sorting, this function will return a tuple with the duration for each of the sorting algorithms as elements in the following order: 
          (1) Heap Sort, (2) Insertion Sort, (3) Merge Sort, and (4) Quick Sort
    '''
    
    # Preparing Lists for sorting    
    heapSortList = copy.deepcopy(data)
    insertionSortList = copy.deepcopy(data) 
    mergeSortList = copy.deepcopy(data)
    quickSortList = copy.deepcopy(data)
        
    # Heap Sort
    # print("",end="\n")
    start = time.perf_counter()
    runHeapSort(heapSortList=heapSortList)
    end = time.perf_counter()
    heapSortDuration = end - start
    
    # Insertion Sort  
    # print("",end="\n") 
    start = time.perf_counter()     
    runInsertionSort(insertionSortList=insertionSortList)
    end = time.perf_counter()
    insertionSortDuration = end - start    
                
    # Merge Sort      
    # print("",end="\n")  
    start = time.perf_counter()
    runMergeSort(mergeSortList=mergeSortList)
    end = time.perf_counter()
    mergeSortDuration = end - start    

    # Quick Sort
    # print("",end="\n")
    start = time.perf_counter()
    runQuickSort(quickSortList=quickSortList)
    end = time.perf_counter()
    quickSortDuration = end - start    
    
    return (heapSortDuration,insertionSortDuration,mergeSortDuration,quickSortDuration)

def main():
    '''
    Description:
        - Creates a shuffled list of integers from 1 to 5,000 and runs the runSortingAlgorithms() 5 times for that list, 
          storing duration results into another list that is turned into a Pandas DataFrame for runtime reporting and analysis.
          
    Inputs:
        - None, but the user may increase algorithm calls by changing range(5) and adjust the list size to be teste by adding changinge the size vairable.
    Outputs:
        - A report with runtime results for each sorting algorithm, and a table describring summary statistics for each algorithm
    '''
    
    size = 5000
    aList = list()
    for i in range(1,size+1):    
        key = i
        value = 'v'
        aList.append((key,value))        
    random.shuffle(aList)
    
    durationTupleList = list()
    for index in range(5):
        durationTuple = runSortingAlgorithms(data=aList,n=size)
        durationTupleList.append(durationTuple)        
        
    df = pd.DataFrame(durationTupleList,columns=['Heap Sort','Insertion Sort','Merge Sort','Quick Sort'])
    print("================")
    print(" RUNTIME REPORT")
    print("================")
    print(df)
    print()
    print(df.describe())
    
        
if __name__ == '__main__':
    main()